package com.example.exam.model.enums;

public enum CategoryName {
    BATTLE,CARGO,PATROL
}
