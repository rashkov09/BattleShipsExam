package com.example.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamPrepApplicationTests {

    @Test
    void contextLoads() {
    }

}
